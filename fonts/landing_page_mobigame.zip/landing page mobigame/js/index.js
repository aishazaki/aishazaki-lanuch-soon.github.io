$(document).ready(function(){
    //countDown
    $(function(){
        var austDay = new Date();
        austDay = new Date(austDay.getFullYear() +1, 1-1 , 26);
        $('#defaultcountdown').countdown({until: austDay , format: 'odHMS'});
    });

    //Form Validation
    $('.form-control').blur(function(){
        var x = document.forms["myForm"]["email"].value;
        var atpos = x.indexOf('@');
        var dotpos = x.lastIndexOf('.');
        if(atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
        {
            $(this).parent().find(".alert-danger").fadeIn(300);
        }
        else{
            $(this).parent().find(".alert-success").fadeIn(300);
        }
    });

    //wow js
    var wow = new WOW({
        mobile: false
    });
    wow.init();
});